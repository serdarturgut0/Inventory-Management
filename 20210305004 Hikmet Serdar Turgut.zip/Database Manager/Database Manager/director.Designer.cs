﻿namespace Database_Manager
{
    partial class director
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            table = new DataGridView();
            button1 = new Button();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)table).BeginInit();
            SuspendLayout();
            // 
            // table
            // 
            table.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            table.Location = new Point(397, 148);
            table.Name = "table";
            table.RowHeadersWidth = 82;
            table.Size = new Size(850, 417);
            table.TabIndex = 0;
            table.CellContentClick += dataGridView1_CellContentClick;
            // 
            // button1
            // 
            button1.Location = new Point(700, 617);
            button1.Name = "button1";
            button1.Size = new Size(225, 77);
            button1.TabIndex = 1;
            button1.Text = "List All Inventory";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16.125F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.Location = new Point(597, 38);
            label1.Name = "label1";
            label1.Size = new Size(426, 59);
            label1.TabIndex = 2;
            label1.Text = "All Active Inventory";
            // 
            // director
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1626, 751);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(table);
            Name = "director";
            Text = "director";
            ((System.ComponentModel.ISupportInitialize)table).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView table;
        private Button button1;
        private Label label1;
    }
}