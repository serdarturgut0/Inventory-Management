﻿namespace Database_Manager
{
    partial class Mainpage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            mainpageBindingSource = new BindingSource(components);
            table = new DataGridView();
            listbut = new Button();
            exitbut = new Button();
            fruitnamebox = new ComboBox();
            pricenum = new NumericUpDown();
            originbox = new TextBox();
            quantnum = new NumericUpDown();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            addbut = new Button();
            updatebut = new Button();
            deletebut = new Button();
            notifyIcon1 = new NotifyIcon(components);
            indexnum1 = new NumericUpDown();
            indexnum = new Label();
            ((System.ComponentModel.ISupportInitialize)mainpageBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)table).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pricenum).BeginInit();
            ((System.ComponentModel.ISupportInitialize)quantnum).BeginInit();
            ((System.ComponentModel.ISupportInitialize)indexnum1).BeginInit();
            SuspendLayout();
            // 
            // mainpageBindingSource
            // 
            mainpageBindingSource.DataSource = typeof(Mainpage);
            // 
            // table
            // 
            table.AllowUserToOrderColumns = true;
            table.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            table.Location = new Point(655, 45);
            table.Name = "table";
            table.RowHeadersWidth = 82;
            table.Size = new Size(854, 487);
            table.TabIndex = 0;
            table.CellContentClick += dataGridView1_CellContentClick;
            // 
            // listbut
            // 
            listbut.Location = new Point(655, 718);
            listbut.Name = "listbut";
            listbut.Size = new Size(168, 53);
            listbut.TabIndex = 1;
            listbut.Text = "List Results";
            listbut.UseVisualStyleBackColor = true;
            listbut.Click += button1_Click;
            // 
            // exitbut
            // 
            exitbut.Location = new Point(1357, 718);
            exitbut.Name = "exitbut";
            exitbut.Size = new Size(152, 53);
            exitbut.TabIndex = 2;
            exitbut.Text = "EXIT";
            exitbut.UseVisualStyleBackColor = true;
            exitbut.Click += exitbut_Click;
            // 
            // fruitnamebox
            // 
            fruitnamebox.FormattingEnabled = true;
            fruitnamebox.Items.AddRange(new object[] { "Apple", "Cherry", "Grapes", "Kiwi", "Strawberry", "Pineapple", "Pear", "Melon" });
            fruitnamebox.Location = new Point(315, 45);
            fruitnamebox.Name = "fruitnamebox";
            fruitnamebox.Size = new Size(242, 40);
            fruitnamebox.TabIndex = 3;
            fruitnamebox.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // pricenum
            // 
            pricenum.Location = new Point(315, 493);
            pricenum.Name = "pricenum";
            pricenum.Size = new Size(242, 39);
            pricenum.TabIndex = 4;
            pricenum.ValueChanged += numericUpDown1_ValueChanged;
            // 
            // originbox
            // 
            originbox.Location = new Point(315, 188);
            originbox.Name = "originbox";
            originbox.Size = new Size(242, 39);
            originbox.TabIndex = 5;
            // 
            // quantnum
            // 
            quantnum.Location = new Point(315, 344);
            quantnum.Name = "quantnum";
            quantnum.Size = new Size(242, 39);
            quantnum.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.Control;
            label1.Font = new Font("Segoe UI", 10.875F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label1.Location = new Point(86, 45);
            label1.Name = "label1";
            label1.Size = new Size(165, 40);
            label1.TabIndex = 7;
            label1.Text = "Fruit Name:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = SystemColors.Control;
            label2.Font = new Font("Segoe UI", 10.875F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label2.Location = new Point(86, 188);
            label2.Name = "label2";
            label2.Size = new Size(102, 40);
            label2.TabIndex = 8;
            label2.Text = "Origin:";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.Control;
            label3.Font = new Font("Segoe UI", 10.875F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label3.Location = new Point(86, 344);
            label3.Name = "label3";
            label3.Size = new Size(133, 40);
            label3.TabIndex = 9;
            label3.Text = "Quantity:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.Control;
            label4.Font = new Font("Segoe UI", 10.875F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label4.Location = new Point(86, 489);
            label4.Name = "label4";
            label4.Size = new Size(84, 40);
            label4.TabIndex = 10;
            label4.Text = "Price:";
            // 
            // addbut
            // 
            addbut.Location = new Point(655, 592);
            addbut.Name = "addbut";
            addbut.Size = new Size(168, 74);
            addbut.TabIndex = 11;
            addbut.Text = "ADD";
            addbut.UseVisualStyleBackColor = true;
            addbut.Click += button1_Click_1;
            // 
            // updatebut
            // 
            updatebut.Location = new Point(1001, 592);
            updatebut.Name = "updatebut";
            updatebut.Size = new Size(161, 74);
            updatebut.TabIndex = 12;
            updatebut.Text = "UPDATE";
            updatebut.UseVisualStyleBackColor = true;
            updatebut.Click += updatebut_Click;
            // 
            // deletebut
            // 
            deletebut.Location = new Point(1359, 592);
            deletebut.Name = "deletebut";
            deletebut.Size = new Size(150, 74);
            deletebut.TabIndex = 13;
            deletebut.Text = "DELETE";
            deletebut.UseVisualStyleBackColor = true;
            deletebut.Click += deletebut_Click;
            // 
            // notifyIcon1
            // 
            notifyIcon1.Text = "notifyIcon1";
            notifyIcon1.Visible = true;
            notifyIcon1.MouseDoubleClick += notifyIcon1_MouseDoubleClick;
            // 
            // indexnum1
            // 
            indexnum1.Location = new Point(315, 627);
            indexnum1.Name = "indexnum1";
            indexnum1.Size = new Size(240, 39);
            indexnum1.TabIndex = 14;
            indexnum1.ValueChanged += numericUpDown1_ValueChanged_1;
            // 
            // indexnum
            // 
            indexnum.AutoSize = true;
            indexnum.BackColor = SystemColors.Control;
            indexnum.Font = new Font("Segoe UI", 10.875F, FontStyle.Regular, GraphicsUnit.Point, 162);
            indexnum.Location = new Point(86, 627);
            indexnum.Name = "indexnum";
            indexnum.Size = new Size(92, 40);
            indexnum.TabIndex = 15;
            indexnum.Text = "Index:";
            // 
            // Mainpage
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1549, 807);
            Controls.Add(indexnum);
            Controls.Add(indexnum1);
            Controls.Add(deletebut);
            Controls.Add(updatebut);
            Controls.Add(addbut);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(quantnum);
            Controls.Add(originbox);
            Controls.Add(pricenum);
            Controls.Add(fruitnamebox);
            Controls.Add(exitbut);
            Controls.Add(listbut);
            Controls.Add(table);
            Name = "Mainpage";
            Text = "Mainpage";
            ((System.ComponentModel.ISupportInitialize)mainpageBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)table).EndInit();
            ((System.ComponentModel.ISupportInitialize)pricenum).EndInit();
            ((System.ComponentModel.ISupportInitialize)quantnum).EndInit();
            ((System.ComponentModel.ISupportInitialize)indexnum1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private BindingSource mainpageBindingSource;
        private DataGridView table;
        private Button listbut;
        private Button exitbut;
        private ComboBox fruitnamebox;
        private NumericUpDown pricenum;
        private TextBox originbox;
        private NumericUpDown quantnum;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button addbut;
        private Button updatebut;
        private Button deletebut;
        private NotifyIcon notifyIcon1;
        private NumericUpDown indexnum1;
        private Label indexnum;
    }
}