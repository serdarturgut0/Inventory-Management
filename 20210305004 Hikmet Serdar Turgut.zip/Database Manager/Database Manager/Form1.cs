using MySqlConnector;
using System.Data;

namespace Database_Manager
{
    public partial class Form1 : Form
    {
        MySqlConnection con = new MySqlConnection("Server=localhost;User ID=root;Password=;Database=fruitstore database");

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String username, password;

            username = usernamebox.Text;
            password = passwordbox.Text;

            try
            {
                String querry = "SELECT * FROM creditials WHERE Username = '" + usernamebox.Text + "' AND Password = '" + passwordbox.Text + "'";
                MySqlDataAdapter adapter = new MySqlDataAdapter(querry, con);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                if (dataTable.Rows.Count > 0)
                {
                    username = usernamebox.Text;
                    password = passwordbox.Text;

                    Mainpage form2 = new Mainpage();
                    form2.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid login details", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    usernamebox.Clear();
                    passwordbox.Clear();
                }
            }
            catch
            {
                MessageBox.Show("Error Occured");
            }
            finally
            {
                con.Close();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            director form3 = new director();
            form3.Show();
            this.Hide();
        }
    }
}
