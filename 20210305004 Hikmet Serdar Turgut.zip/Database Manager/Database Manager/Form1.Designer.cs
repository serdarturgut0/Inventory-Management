﻿namespace Database_Manager
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            loginbutton = new Button();
            label1 = new Label();
            passwordbox = new TextBox();
            usernamebox = new TextBox();
            label2 = new Label();
            label3 = new Label();
            button1 = new Button();
            SuspendLayout();
            // 
            // loginbutton
            // 
            loginbutton.BackColor = SystemColors.ActiveCaption;
            loginbutton.Location = new Point(448, 512);
            loginbutton.Name = "loginbutton";
            loginbutton.Size = new Size(201, 64);
            loginbutton.TabIndex = 0;
            loginbutton.Text = "Login";
            loginbutton.UseVisualStyleBackColor = false;
            loginbutton.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 16.125F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.ForeColor = Color.CadetBlue;
            label1.Location = new Point(283, 84);
            label1.Name = "label1";
            label1.Size = new Size(546, 51);
            label1.TabIndex = 1;
            label1.Text = "FruitStore Stock Manager";
            // 
            // passwordbox
            // 
            passwordbox.Location = new Point(388, 424);
            passwordbox.Name = "passwordbox";
            passwordbox.Size = new Size(329, 39);
            passwordbox.TabIndex = 2;
            passwordbox.UseSystemPasswordChar = true;
            // 
            // usernamebox
            // 
            usernamebox.Location = new Point(388, 342);
            usernamebox.Name = "usernamebox";
            usernamebox.Size = new Size(329, 39);
            usernamebox.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(249, 345);
            label2.Name = "label2";
            label2.Size = new Size(133, 32);
            label2.TabIndex = 4;
            label2.Text = "Username: ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(258, 427);
            label3.Name = "label3";
            label3.Size = new Size(123, 32);
            label3.TabIndex = 5;
            label3.Text = "Password: ";
            label3.Click += label3_Click;
            // 
            // button1
            // 
            button1.Location = new Point(448, 608);
            button1.Name = "button1";
            button1.Size = new Size(201, 46);
            button1.TabIndex = 6;
            button1.Text = "Only List Mode";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1076, 707);
            Controls.Add(button1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(usernamebox);
            Controls.Add(passwordbox);
            Controls.Add(label1);
            Controls.Add(loginbutton);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button loginbutton;
        private Label label1;
        private TextBox passwordbox;
        private TextBox usernamebox;
        private Label label2;
        private Label label3;
        private Button button1;
    }
}
