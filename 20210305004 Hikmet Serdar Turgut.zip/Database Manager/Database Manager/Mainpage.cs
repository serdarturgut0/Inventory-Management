﻿using Microsoft.VisualBasic.ApplicationServices;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Database_Manager
{
    public partial class Mainpage : Form
    {
        MySqlConnection con = new MySqlConnection("Server=localhost;User ID=root;Password=;Database=fruitstore database");

        public Mainpage()
        {
            InitializeComponent();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string Query = "SELECT * FROM inventory";
                MySqlCommand cmd = new MySqlCommand(Query, con);
                MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                table.DataSource = dt;
                table.Refresh();
                table.Columns["FruitName"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                table.Columns["Origin"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                table.Columns["Quantity"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                table.Columns["Price"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred When Showing Data: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(fruitnamebox.Text) ||
                string.IsNullOrWhiteSpace(originbox.Text) ||
                string.IsNullOrWhiteSpace(quantnum.Text) ||
                string.IsNullOrWhiteSpace(pricenum.Text) ||
                string.IsNullOrWhiteSpace(indexnum1.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            string name = fruitnamebox.Text;
            string origin = originbox.Text;
            string quantity = quantnum.Text;
            string price = pricenum.Text;
            string slot = indexnum1.Text;

            string checkExistenceQuery = "SELECT COUNT(*) FROM inventory WHERE SlotNumber = @SlotNumber";

            try
            {
                using (var connection = new MySqlConnection("Server=localhost;User ID=root;Password=;Database=fruitstore database"))
                {
                    connection.Open();

                    using (var cmd = new MySqlCommand(checkExistenceQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@SlotNumber", slot);

                        int S = Convert.ToInt32(cmd.ExecuteScalar());

                    }
                    string insertQuery = "INSERT INTO inventory (FruitName, Origin, Price, SlotNumber, Quantity) VALUES (@FruitName, @Origin, @Price, @SlotNumber, @Quantity)";
                    using (var cmd = new MySqlCommand(insertQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@FruitName", name);
                        cmd.Parameters.AddWithValue("@Origin", origin);
                        cmd.Parameters.AddWithValue("@Price", price);
                        cmd.Parameters.AddWithValue("@Quantity", quantity);
                        cmd.Parameters.AddWithValue("@SlotNumber", slot);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Veri başarıyla eklendi.");
                        }
                        else
                        {
                            MessageBox.Show("Veri eklenemedi.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }


        private void updatebut_Click(object sender, EventArgs e)
        {
            if (table.SelectedRows.Count == 0)
            {
                MessageBox.Show("Lütfen güncellenecek bir satır seçin.");
                return;
            }

            DataGridViewRow selectedRow = table.SelectedRows[0];

            string fruitname = fruitnamebox.Text;
            string origin = originbox.Text;
            string quantity = quantnum.Text;
            string price = pricenum.Text;
            string slot = indexnum1.Text;
            string unitNumberToUpdate = selectedRow.Cells["SlotNumber"].Value.ToString();

            string updateQuery = "UPDATE inventory SET FruitName = @FruitName, Origin = @Origin, Price = @Price, Quantity = @Quantity WHERE SlotNumber = @SlotNumber";

            try
            {
                using (var connection = new MySqlConnection("Server=localhost; User ID=root; Password=; Database=fruitstore database"))
                {
                    connection.Open();

                    using (var cmd = new MySqlCommand(updateQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@SlotNumber", unitNumberToUpdate);
                        cmd.Parameters.AddWithValue("@FruitName", fruitname);
                        cmd.Parameters.AddWithValue("@Origin", origin);
                        cmd.Parameters.AddWithValue("@Quantity", quantity);
                        cmd.Parameters.AddWithValue("@Price", price);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data updated succesfuly.");
                        }
                        else
                        {
                            MessageBox.Show("Error happened.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occured: {ex.Message}");
            }
        }




        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void exitbut_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void deletebut_Click(object sender, EventArgs e)
        {
            try
            {
                DataGridViewRow selectedRow = table.SelectedRows[0];

                int slot = Convert.ToInt32(selectedRow.Cells["SlotNumber"].Value);

                string deleteQuery = "DELETE FROM inventory WHERE SlotNumber = @SlotNumber";

                using (var connection = new MySqlConnection("Server=localhost; User ID=root; Password=; Database=fruitstore database"))
                {
                    connection.Open();

                    using (var cmd = new MySqlCommand(deleteQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@SlotNumber", slot);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Slot deleted.");
                        }
                        else
                        {
                            MessageBox.Show("Error, slot cannot be deleted.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Something happened even though nothing happened: {ex.Message}");
            }
        }


        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged_1(object sender, EventArgs e)
        {

        }
    }
}