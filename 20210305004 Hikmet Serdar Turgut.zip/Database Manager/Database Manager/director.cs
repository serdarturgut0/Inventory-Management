﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Database_Manager
{
    public partial class director : Form
    {
        public director()
        {
            InitializeComponent();
        }

        MySqlConnection con = new MySqlConnection("Server=localhost;User ID=root;Password=;Database=fruitstore database");

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string Query = "SELECT * FROM inventory";
                MySqlCommand cmd = new MySqlCommand(Query, con);
                MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                table.DataSource = dt;
                table.Refresh();
                table.Columns["FruitName"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                table.Columns["Origin"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                table.Columns["Quantity"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                table.Columns["Price"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Occurred When Showing Data: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
